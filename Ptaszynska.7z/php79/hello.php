<?php

	session_start();
	
	if (!isset($_SESSION['udanarejestracja']))
	{
		header('Location: index.php');
		exit();
	}
	else
	{
		unset($_SESSION['udanarejestracja']);
	}
	
	//Usuwanie zmiennych pamiętających wartości wpisane do formularza
	if (isset($_SESSION['fr_login'])) unset($_SESSION['fr_login']);
	if (isset($_SESSION['fr_email'])) unset($_SESSION['fr_email']);
	if (isset($_SESSION['fr_password1'])) unset($_SESSION['fr_password1']);
	if (isset($_SESSION['fr_password2'])) unset($_SESSION['fr_password2']);

	//Usuwanie błędów rejestracji
	if (isset($_SESSION['e_login'])) unset($_SESSION['e_login']);
	if (isset($_SESSION['e_email'])) unset($_SESSION['e_email']);
	if (isset($_SESSION['e_password'])) unset($_SESSION['e_password']);

?>

<!DOCTYPE HTML>
<html lang="eng">
<head>
	<meta charset="utf-8" />
	<title>Book Eaters</title>
	<meta name="description" content="A website in which you can search, buy and sell books" />
	<meta name="keywords" content="book, recommendation, buy, sell, searching, rating" />
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	

	
	<link rel="stylesheet" type="text/css" href="style.css" />
	
</head>

<body>

	<div id="container">
	
		<div id="logo">
			<h1>Book Eaters</h1>
			<div class="title1">
			<a href="MyLibrary.html"class="titlelink">
			My library</a>
			</div>
			<div class="title2">
			<a href="Home.html"class="titlelink" >
			Home</a>
			</div>
			<div class="title3">
			<a href="Alphabetic.html"class="titlelink">
			Alphabetic</a>
			</div>
			<div class="title4">
			<a href="Genres.html"class="titlelink">
			Genres</a>
			</div>
			
			
		</div>
	
		<div id="left">
		<div id="side">
		<br>
		<div> You succesed at creating an account </div><br /><br />
	
	<a href="index.php"class="titlelink3" >Log in to your account</a>
			</div>
			</div>
			
			<div id="right">
			<div id="title"> <form action="result.php" method="post">
			Search<br />
			<input type="text" name="title" placeholder="Title/Author">
			<input type="submit"value="Search"  name="search" />
			<br /><br />
			</form>
			</div>
			<div id="genre">
			<form action="result1.php"  method="post">
			Search by Genre<br />
			<select name="metoda">
			<option value="Biography" />Biography
			<option value="Children's" />Children's
			<option value="Comics" />Comics
			<option value="Crime" />Crime 
			<option value="Fantasy" />Fantasy 
			<option value="History" />History 
			<option value="Horror" />Horror
			<option value="Poetry" />Poetry 
			<option value="Romance" />Romance 
			<option value="Science Fiction" />Science Fiction
			<br /><br />
			<input type="submit" value="Search"name="search1" />
				</form>
			<br /><br />
			</div>
		</div>
		
		<div id="content">
			<h2 class="title"> Last Updates</h2>
			
			<?php
			 @ $db = new mysqli('localhost','root','','bookbase');
      
      if (mysqli_connect_errno())
      {
        echo 'We cannot connect with database now. Try again later.';
        exit;
      }
      $db->query('SET NAMES utf8');
      $db->query('SET CHARACTER_SET utf8_unicode_ci');
      $zapytanie = "select id,picture from bookbase1 ORDER BY id DESC LIMIT 5";
      $wynik = $db->query($zapytanie);
      $ile_znaleziono = $wynik->num_rows;
      for ($i=0;$i<$ile_znaleziono;$i++)
      {
		$wiersz = $wynik->fetch_assoc();
        echo '<span class="picture">'. '<a class="titlelink2" href="detail.php?id='.$wiersz['id'].'">'.'<img src="'. $wiersz['picture'] . '" width="150" />'.'</a>'.'</span>';

      }
      $wynik->free();
      $db->close();
    
    ?> 
			<h2 class="title">Best Rating</h2>
			<?php
			 @ $db = new mysqli('localhost','root','','bookbase');
      
      if (mysqli_connect_errno())
      {
        echo 'We cannot connect with database now. Try again later.';
        exit;
      }
      $db->query('SET NAMES utf8');
      $db->query('SET CHARACTER_SET utf8_unicode_ci');
      $zapytanie = "select id,picture,suma/ocen  from bookbase1 ORDER BY suma/ocen DESC LIMIT 5";
      $wynik = $db->query($zapytanie);
      $ile_znaleziono = $wynik->num_rows;
      for ($i=0;$i<$ile_znaleziono;$i++)
      {
        $wiersz = $wynik->fetch_assoc();
        echo '<span class="picture">'. '<a class="titlelink2" href="detail.php?id='.$wiersz['id'].'">'.'<img src="'. $wiersz['picture'] . '" width="150" />'.'</a>'.'</span>';
        

      }
      $wynik->free();
      $db->close();
    
    ?> 
		</div>

</body>
</html>
