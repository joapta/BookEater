<?php
	session_start();
?>


 <!DOCTYPE HTML>
<html lang="eng">
<head>
	<meta charset="utf-8" />
	<title>Book Eaters</title>
	<meta name="description" content="A website in which you can search, buy and sell books" />
	<meta name="keywords" content="book, recommendation, buy, sell, searching, rating" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="stylesheet" type="text/css" href="style.css" />
	
	</style>

</head>

<body>

	<div id="container">
	
		<div id="logo">
			<h1>Book Eaters</h1>
			<div class="title1">
			<a href="MyLibrary.php"class="titlelink">
			My library</a>
			</div>
			<div class="title2">
			<a href="index.php"class="titlelink" >
			Home</a>
			</div>
			<div class="title3">
			<a href="Alphabetic.php"class="titlelink">
			Alphabetic</a>
			</div>
			<div class="title4">
			<a href="Genres.php"class="titlelink">
			Genres</a>
			</div>
			
			
		</div>
	
		
		<div id="left">
		<div id="side">
			<?php
				if ((isset($_SESSION['zalogowany'])) && ($_SESSION['zalogowany']==true))
				{
					
					echo "<p>Hello ".$_SESSION['login'].'!  <a class="titlelink3" href="logout.php">Log out!</a> </p>';

				}
				else{
					
					echo '<form action="login1.php" method="post">';
						echo 'Login <br />'.'<input type="text" name="login">'.'<br /><br />';
						echo 'Password <br />'.'<input type="password" name="password">'.'<br /><br />';
						echo '<input type="submit" value="Log in"><br /><br />';
						echo '<div>'.'<a href="registration.php"class="titlelink">'.'Create an account </a><br />'.'</div>';
					echo'</form>';
					if(isset($_SESSION['blad']))	echo $_SESSION['blad'];	
				}
			?>
			</div>
		
			</div>
			
			<div id="right">
			<div id="title"> <form action="result.php" method="post">
			Search<br />
			<input type="text" name="title" placeholder="Title/Author">
			<input type="submit"value="Search"  name="search" />
			<br /><br />
			</form>
			</div>
			<div id="genre">
			<form action="result1.php"  method="post">
			Search by Genre<br />
			<select name="metoda">
			<option value="Biography" />Biography
			<option value="Children" />Children
			<option value="Comics" />Comics
			<option value="Crime" />Crime 
			<option value="Fantasy" />Fantasy 
			<option value="History" />History 
			<option value="Horror" />Horror
			<option value="Poetry" />Poetry 
			<option value="Romance" />Romance 
			<option value="Science Fiction" />Science Fiction
			<br /><br />
			<input type="submit" value="Search"name="search1" />
			<br /><br />
				</form>
			</div>
		</div>
		
		<div id="content">
		<h2 class="title">Search results
		<br>
			 <?php
      
      $metoda = $_POST['metoda'];
    
      if (!get_magic_quotes_gpc())
      {
        
        $metoda = addslashes($metoda);
      }
      @ $db = new mysqli('localhost','root','','bookbase');
      
      if (mysqli_connect_errno())
      {
        echo 'We cannot connect with database now. Try again later.';
        exit;
      }
      $db->query('SET NAMES utf8');
      $db->query('SET CHARACTER_SET utf8_unicode_ci');
      $zapytanie = "select id,title,author,picture from bookbase1 where type like '%".$metoda."%'";
      $wynik = $db->query($zapytanie);
      $ile_znaleziono = $wynik->num_rows;
      echo '<div> Number of found books: '.$ile_znaleziono.'</div>';
	  echo '<div> For Genre: '.$metoda.'</div><br />';
      for ($i=0;$i<$ile_znaleziono;$i++)
      {
        $wiersz = $wynik->fetch_assoc();
		echo '<div class="polozenie">'.'<img src="'. $wiersz['picture'] . '" width="120", id="picture"/>';
        echo '<b>'.($i+1).'<a class="titlelink2" href="detail.php?id='.$wiersz['id'].'">.Title: '.$wiersz['title'].'</a>'.'</b><br />';
        echo '<a class="titlelink2" href="detail2.php?author='.$wiersz['author'].'">Author: '.$wiersz['author'].'</a>'.'</div><br /><br />';
      }
      $wynik->free();
      $db->close();
    ?> 
		</div>

</body>
</html>