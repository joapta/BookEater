<?php

	session_start();
	
	if (isset($_POST['email']))
	{
		
		$wszystko_OK=true;
		$login = $_POST['login'];
		if ((strlen($login)<5) || (strlen($login)>15))
		{
			$wszystko_OK=false;
			$_SESSION['e_login']="Login has to have between 5 to 15 characters!";
		}
		if (ctype_alnum($login)==false)
		{
			$wszystko_OK=false;
			$_SESSION['e_login']="Login cannot have polish letters";
		}
		
		
		$email = $_POST['email'];
		$emailB = filter_var($email, FILTER_SANITIZE_EMAIL);
		
		if ((filter_var($emailB, FILTER_VALIDATE_EMAIL)==false) || ($emailB!=$email))
		{
			$wszystko_OK=false;
			$_SESSION['e_email']="Give a correct e-mail address!";
		}
		
		
		$password1 = $_POST['password1'];
		$password2 = $_POST['password2'];
		if ((strlen($password1)<5) || (strlen($password1)>15))
		{
			$wszystko_OK=false;
			$_SESSION['e_password']="Password has to have between 5 to 15 characters!";
		}
		
		if ($password1!=$password2)
		{
			$wszystko_OK=false;
			$_SESSION['e_password']="Passwords are not the same!";
		}	

		$password_hash = password_hash($password1, PASSWORD_DEFAULT);
		
		
		
		$_SESSION['fr_login'] = $login;
		$_SESSION['fr_email'] = $email;
		$_SESSION['fr_password1'] = $password1;
		$_SESSION['fr_password2'] = $password2;
		
		
		require_once "connect.php";
		mysqli_report(MYSQLI_REPORT_STRICT);
		
		try 
		{
			$polaczenie = new mysqli($host, $db_user, $db_password, $db_name);
			if ($polaczenie->connect_errno!=0)
			{
				throw new Exception(mysqli_connect_errno());
			}
			else
			{
				
				$rezultat = $polaczenie->query("SELECT id FROM users WHERE email='$email'");
				
				if (!$rezultat) throw new Exception($polaczenie->error);
				
				$ile_takich_maili = $rezultat->num_rows;
				if($ile_takich_maili>0)
				{
					$wszystko_OK=false;
					$_SESSION['e_email']="The account with this email already exist!";
				}		

				
				$rezultat = $polaczenie->query("SELECT id FROM users WHERE login='$login'");
				
				if (!$rezultat) throw new Exception($polaczenie->error);
				
				$ile_takich_loginow = $rezultat->num_rows;
				if($ile_takich_loginow>0)
				{
					$wszystko_OK=false;
					$_SESSION['e_login']="There is a user with this login already";
				}
				
				if ($wszystko_OK==true)
				{
					
					
					if ($polaczenie->query("INSERT INTO users VALUES (NULL, '$login', '$password_hash', '$email')"))
					{
						$_SESSION['udanarejestracja']=true;
						header('Location: hello.php');
					}
					else
					{
						throw new Exception($polaczenie->error);
					}
					
				}
				
				$polaczenie->close();
			}
			
		}
		catch(Exception $e)
		{
			echo '<span style="color:red;">Connect Error! Please try again later!</span>';
			echo '<br />Developer Information: '.$e;
		}
		
	}
	
	
?>
<!DOCTYPE HTML>
<html lang="eng">
<head>
	<meta charset="utf-8" />
	<title>Book Eaters</title>
	<meta name="description" content="A website in which you can search, buy and sell books" />
	<meta name="keywords" content="book, recommendation, buy, sell, searching, rating" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="stylesheet" type="text/css" href="style.css" />
	

</head>

<body>

	<div id="container">
	
		<div id="logo">
			<h1>Book Eaters</h1>
			<div class="title1">
			<a href="MyLibrary.php"class="titlelink">
			My library</a>
			</div>
			<div class="title2">
			<a href="index.php"class="titlelink" >
			Home</a>
			</div>
			<div class="title3">
			<a href="Alphabetic.php"class="titlelink">
			Alphabetic</a>
			</div>
			<div class="title4">
			<a href="Genres.php"class="titlelink">
			Genres</a>
			</div>
			
			
		</div>
		
	<div id="left">
			<div id="side">
			<?php
				if ((isset($_SESSION['zalogowany'])) && ($_SESSION['zalogowany']==true))
				{
					
					echo "<p>Hello ".$_SESSION['login'].'!  <a class="titlelink3" href="logout.php">Log out!</a> </p>';
	
				}
				else{
					
					echo '<form action="login1.php" method="post">';
						echo 'Login <br />'.'<input type="text" name="login">'.'<br /><br />';
						echo 'Password <br />'.'<input type="password" name="password">'.'<br /><br />';
						echo '<input type="submit" value="Log in"><br /><br />';
						echo '<div>'.'<a href="registration.php"class="titlelink">'.'Create an account </a><br />'.'</div>';
					echo'</form>';
					if(isset($_SESSION['blad']))	echo $_SESSION['blad'];	
				}
			?>
			</div>
			
		
			</div>
			
			<div id="right">
			<div id="title"> <form action="result.php" method="post">
			Search<br />
			<input type="text" name="title" placeholder="Title/Author">
			<input type="submit"value="Search"  name="search" />
			<br /><br />
			</form>
			</div>
			<div id="genre">
			<form action="result1.php"  method="post">
			Search by Genre<br />
			<select name="metoda">
			<option value="Biography" />Biography
			<option value="Children" />Children
			<option value="Comics" />Comics
			<option value="Crime" />Crime 
			<option value="Fantasy" />Fantasy 
			<option value="History" />History 
			<option value="Horror" />Horror
			<option value="Poetry" />Poetry 
			<option value="Romance" />Romance 
			<option value="Science Fiction" />Science Fiction
			<br /><br />
			<input type="submit" value="Search"name="search1" />
			<br /><br />
				</form>
			</div>
		</div>
		
		<div id="content">
			<div id="registration"> 
			<form  method="post">
	Login: <br /> <input type="text" value="<?php
			if (isset($_SESSION['fr_login']))
			{
				echo $_SESSION['fr_login'];
				unset($_SESSION['fr_login']);
			}
		?>" name="login" /><br />
		
		<?php
			if (isset($_SESSION['e_login']))
			{
				echo '<div class="error">'.$_SESSION['e_login'].'</div>';
				unset($_SESSION['e_login']);
			}
		?>
		
		E-mail: <br /> <input type="text" value="<?php
			if (isset($_SESSION['fr_email']))
			{
				echo $_SESSION['fr_email'];
				unset($_SESSION['fr_email']);
			}
		?>" name="email" /><br />
		
		<?php
			if (isset($_SESSION['e_email']))
			{
				echo '<div class="error">'.$_SESSION['e_email'].'</div>';
				unset($_SESSION['e_email']);
			}
		?>
		
		Your Password: <br /> <input type="password"  value="<?php
			if (isset($_SESSION['fr_password1']))
			{
				echo $_SESSION['fr_password1'];
				unset($_SESSION['fr_password1']);
			}
		?>" name="password1" /><br />
		
		<?php
			if (isset($_SESSION['e_password']))
			{
				echo '<div class="error">'.$_SESSION['e_password'].'</div>';
				unset($_SESSION['e_password']);
			}
		?>		
		
		Repeat Password: <br /> <input type="password" value="<?php
			if (isset($_SESSION['fr_password2']))
			{
				echo $_SESSION['fr_password2'];
				unset($_SESSION['fr_password2']);
			}
		?>" name="password2" /><br />
		
		
	
		
			<br /><br />
			<input type="submit" value="Create an account";
			<br /><br />
			</form>
		</div>
</div>
</body>
</html>
